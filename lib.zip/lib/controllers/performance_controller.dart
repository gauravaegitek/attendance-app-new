// // lib/controllers/performance_controller.dart

// import 'package:get/get.dart';

// import '../models/performance_model.dart';
// import '../services/performance_api_service.dart';

// class PerformanceController extends GetxController {
//   // ─── Loading ───────────────────────────────────────────────────────────────
//   final isLoadingScore     = false.obs;
//   final isLoadingRanking   = false.obs;
//   final isLoadingReviews   = false.obs;
//   final isSubmittingReview = false.obs;
//   final isLoadingRoles     = false.obs;

//   // ─── Data ──────────────────────────────────────────────────────────────────
//   final employeeScore = Rxn<EmployeeScoreModel>();
//   final rankings      = <RankingModel>[].obs;
//   final reviews       = <ReviewModel>[].obs;

//   // ✅ Roles from /api/Role — department filter ke liye
//   final rolesList = <String>[].obs;

//   // ─── Filter state ──────────────────────────────────────────────────────────
//   final selectedMonth = DateTime.now().month.obs;
//   final selectedYear  = DateTime.now().year.obs;
//   final selectedDept  = ''.obs;

//   // ─── Error ─────────────────────────────────────────────────────────────────
//   final errorScore   = ''.obs;
//   final errorRanking = ''.obs;
//   final errorReviews = ''.obs;

//   // ===========================================================================
//   // Fetch: Roles from /api/Role
//   // ===========================================================================
//   Future<void> fetchRoles() async {
//     if (rolesList.isNotEmpty) return; // already loaded
//     isLoadingRoles.value = true;
//     try {
//       final result = await PerformanceApiService.getRoles();
//       rolesList.value = result;
//     } catch (e) {
//       // silent fail — chips nahi dikhenge
//     } finally {
//       isLoadingRoles.value = false;
//     }
//   }

//   // ===========================================================================
//   // Fetch: Employee Score
//   // ===========================================================================
//   Future<void> fetchEmployeeScore({
//     required int month,
//     required int year,
//     required int userId,
//   }) async {
//     isLoadingScore.value = true;
//     errorScore.value     = '';
//     try {
//       final result = await PerformanceApiService.getEmployeeScore(
//         month:  month,
//         year:   year,
//         userId: userId,
//       );
//       employeeScore.value = result;
//       if (result == null) errorScore.value = 'No score data found.';
//     } catch (e) {
//       errorScore.value = 'Failed to load score: $e';
//     } finally {
//       isLoadingScore.value = false;
//     }
//   }

//   // ===========================================================================
//   // Fetch: Rankings
//   // ===========================================================================
//   Future<void> fetchRanking({
//     required int month,
//     required int year,
//     String? department,
//   }) async {
//     isLoadingRanking.value = true;
//     errorRanking.value     = '';
//     try {
//       final result = await PerformanceApiService.getRanking(
//         month:      month,
//         year:       year,
//         department: department ?? selectedDept.value,
//       );
//       rankings.value = result;
//       if (result.isEmpty) errorRanking.value = 'No ranking data found.';
//     } catch (e) {
//       errorRanking.value = 'Failed to load rankings: $e';
//     } finally {
//       isLoadingRanking.value = false;
//     }
//   }

//   // ===========================================================================
//   // Fetch: Reviews
//   // ===========================================================================
//   Future<void> fetchReviews({
//     required int month,
//     required int year,
//   }) async {
//     isLoadingReviews.value = true;
//     errorReviews.value     = '';
//     try {
//       final result = await PerformanceApiService.getReviews(
//         month: month,
//         year:  year,
//       );
//       reviews.value = result;
//     } catch (e) {
//       errorReviews.value = 'Failed to load reviews: $e';
//     } finally {
//       isLoadingReviews.value = false;
//     }
//   }

//   // ===========================================================================
//   // Submit: Review (Admin only)
//   // ===========================================================================
//   Future<bool> submitReview(ReviewRequestModel request) async {
//     isSubmittingReview.value = true;
//     try {
//       final success = await PerformanceApiService.submitReview(request);
//       if (success) {
//         Get.snackbar(
//           'Success',
//           'Review submitted successfully',
//           snackPosition: SnackPosition.BOTTOM,
//         );
//         await fetchReviews(month: request.month, year: request.year);
//         return true;
//       } else {
//         Get.snackbar(
//           'Error',
//           'Failed to submit review. Please try again.',
//           snackPosition: SnackPosition.BOTTOM,
//         );
//         return false;
//       }
//     } catch (e) {
//       Get.snackbar('Error', e.toString(),
//           snackPosition: SnackPosition.BOTTOM);
//       return false;
//     } finally {
//       isSubmittingReview.value = false;
//     }
//   }

//   // ===========================================================================
//   // Helpers
//   // ===========================================================================

//   void setMonthYear(int month, int year) {
//     selectedMonth.value = month;
//     selectedYear.value  = year;
//   }

//   void updateDepartment(String dept) {
//     selectedDept.value = dept;
//   }

//   RankingModel? rankOf(int userId) =>
//       rankings.firstWhereOrNull((r) => r.userId == userId);

//   ReviewModel? reviewOf(int userId) =>
//       reviews.firstWhereOrNull((r) => r.userId == userId);
// }










// lib/controllers/performance_controller.dart
// ✅ CHANGES:
//   • fromDate / toDate state added
//   • setDateRange() helper
//   • myReviews list + isLoadingMyReviews + errorMyReviews
//   • fetchMyReviews() — multi-month support

// import 'package:get/get.dart';

// import '../models/performance_model.dart';
// import '../services/performance_api_service.dart';

// class PerformanceController extends GetxController {
//   // ─── Loading ───────────────────────────────────────────────────────────────
//   final isLoadingScore      = false.obs;
//   final isLoadingRanking    = false.obs;
//   final isLoadingReviews    = false.obs;
//   final isSubmittingReview  = false.obs;
//   final isLoadingRoles      = false.obs;
//   final isLoadingMyReviews  = false.obs; // ✅ NEW

//   // ─── Data ──────────────────────────────────────────────────────────────────
//   final employeeScore = Rxn<EmployeeScoreModel>();
//   final rankings      = <RankingModel>[].obs;
//   final reviews       = <ReviewModel>[].obs;
//   final myReviews     = <ReviewModel>[].obs; // ✅ NEW

//   // ✅ Roles from /api/Role
//   final rolesList = <String>[].obs;

//   // ─── Filter state ──────────────────────────────────────────────────────────
//   final selectedMonth = DateTime.now().month.obs;
//   final selectedYear  = DateTime.now().year.obs;
//   final selectedDept  = ''.obs;

//   // ✅ NEW — Date range for My Reviews
//   final fromDate = Rx<DateTime>(
//     DateTime(DateTime.now().year, DateTime.now().month, 1),
//   );
//   final toDate = Rx<DateTime>(
//     DateTime(DateTime.now().year, DateTime.now().month + 1, 0),
//   );

//   // ─── Error ─────────────────────────────────────────────────────────────────
//   final errorScore     = ''.obs;
//   final errorRanking   = ''.obs;
//   final errorReviews   = ''.obs;
//   final errorMyReviews = ''.obs; // ✅ NEW

//   // ===========================================================================
//   // ✅ NEW — Set date range
//   // ===========================================================================
//   void setDateRange({required DateTime from, required DateTime to}) {
//     fromDate.value = from;
//     toDate.value   = to;
//   }

//   // ===========================================================================
//   // ✅ NEW — Fetch: My Reviews (employee)
//   //   Calls /api/Performance/myreviews for each month in [fromDate, toDate]
//   //   and combines results sorted by year+month desc.
//   // ===========================================================================
//   Future<void> fetchMyReviews({
//     required DateTime fromDate,
//     required DateTime toDate,
//   }) async {
//     isLoadingMyReviews.value = true;
//     errorMyReviews.value     = '';
//     myReviews.clear();

//     try {
//       // Build list of (month, year) combos covered by the date range
//       final months = <({int month, int year})>[];
//       var cursor = DateTime(fromDate.year, fromDate.month, 1);
//       final end  = DateTime(toDate.year, toDate.month, 1);

//       while (!cursor.isAfter(end)) {
//         months.add((month: cursor.month, year: cursor.year));
//         // Advance one month
//         cursor = DateTime(cursor.year, cursor.month + 1, 1);
//       }

//       // Parallel fetch for all months
//       final results = await Future.wait<List<ReviewModel>>(
//         months.map(
//           (m) => PerformanceApiService.getMyReviews(
//             month: m.month,
//             year:  m.year,
//           ),
//         ),
//       );

//       // Flatten + sort by year+month desc (newest first)
//       final combined = results.expand<ReviewModel>((r) => r).toList()
//         ..sort((a, b) {
//           final cmpYear = b.year.compareTo(a.year);
//           if (cmpYear != 0) return cmpYear;
//           return b.month.compareTo(a.month);
//         });

//       myReviews.assignAll(combined);

//       if (combined.isEmpty) {
//         errorMyReviews.value = 'No reviews found for selected period.';
//       }
//     } catch (e) {
//       errorMyReviews.value = 'Failed to load reviews: $e';
//     } finally {
//       isLoadingMyReviews.value = false;
//     }
//   }

//   // ===========================================================================
//   // Fetch: Roles from /api/Role
//   // ===========================================================================
//   Future<void> fetchRoles() async {
//     if (rolesList.isNotEmpty) return;
//     isLoadingRoles.value = true;
//     try {
//       final result = await PerformanceApiService.getRoles();
//       rolesList.value = result;
//     } catch (e) {
//       // silent fail
//     } finally {
//       isLoadingRoles.value = false;
//     }
//   }

//   // ===========================================================================
//   // Fetch: Employee Score
//   // ===========================================================================
//   Future<void> fetchEmployeeScore({
//     required int month,
//     required int year,
//     required int userId,
//   }) async {
//     isLoadingScore.value = true;
//     errorScore.value     = '';
//     try {
//       final result = await PerformanceApiService.getEmployeeScore(
//         month:  month,
//         year:   year,
//         userId: userId,
//       );
//       employeeScore.value = result;
//       if (result == null) errorScore.value = 'No score data found.';
//     } catch (e) {
//       errorScore.value = 'Failed to load score: $e';
//     } finally {
//       isLoadingScore.value = false;
//     }
//   }

//   // ===========================================================================
//   // Fetch: Rankings
//   // ===========================================================================
//   Future<void> fetchRanking({
//     required int month,
//     required int year,
//     String? department,
//   }) async {
//     isLoadingRanking.value = true;
//     errorRanking.value     = '';
//     try {
//       final result = await PerformanceApiService.getRanking(
//         month:      month,
//         year:       year,
//         department: department ?? selectedDept.value,
//       );
//       rankings.value = result;
//       if (result.isEmpty) errorRanking.value = 'No ranking data found.';
//     } catch (e) {
//       errorRanking.value = 'Failed to load rankings: $e';
//     } finally {
//       isLoadingRanking.value = false;
//     }
//   }

//   // ===========================================================================
//   // Fetch: Reviews (Admin)
//   // ===========================================================================
//   Future<void> fetchReviews({
//     required int month,
//     required int year,
//   }) async {
//     isLoadingReviews.value = true;
//     errorReviews.value     = '';
//     try {
//       final result = await PerformanceApiService.getReviews(
//         month: month,
//         year:  year,
//       );
//       reviews.value = result;
//     } catch (e) {
//       errorReviews.value = 'Failed to load reviews: $e';
//     } finally {
//       isLoadingReviews.value = false;
//     }
//   }

//   // ===========================================================================
//   // Submit: Review (Admin only)
//   // ===========================================================================
//   Future<bool> submitReview(ReviewRequestModel request) async {
//     isSubmittingReview.value = true;
//     try {
//       final success = await PerformanceApiService.submitReview(request);
//       if (success) {
//         Get.snackbar(
//           'Success',
//           'Review submitted successfully',
//           snackPosition: SnackPosition.BOTTOM,
//         );
//         await fetchReviews(month: request.month, year: request.year);
//         return true;
//       } else {
//         Get.snackbar(
//           'Error',
//           'Failed to submit review. Please try again.',
//           snackPosition: SnackPosition.BOTTOM,
//         );
//         return false;
//       }
//     } catch (e) {
//       Get.snackbar('Error', e.toString(), snackPosition: SnackPosition.BOTTOM);
//       return false;
//     } finally {
//       isSubmittingReview.value = false;
//     }
//   }

//   // ===========================================================================
//   // Helpers
//   // ===========================================================================
//   void setMonthYear(int month, int year) {
//     selectedMonth.value = month;
//     selectedYear.value  = year;
//   }

//   void updateDepartment(String dept) {
//     selectedDept.value = dept;
//   }

//   RankingModel? rankOf(int userId) =>
//       rankings.firstWhereOrNull((r) => r.userId == userId);

//   ReviewModel? reviewOf(int userId) =>
//       reviews.firstWhereOrNull((r) => r.userId == userId);
// }






// lib/controllers/performance_controller.dart

import 'package:get/get.dart';
import '../models/performance_model.dart';
import '../services/performance_api_service.dart';

class PerformanceController extends GetxController {
  // ─── Loading ───────────────────────────────────────────────────────────────
  final isLoadingScore = false.obs;
  final isLoadingRanking = false.obs;
  final isLoadingReviews = false.obs;
  final isSubmittingReview = false.obs;
  final isLoadingRoles = false.obs;
  final isLoadingMyReviews = false.obs;

  // ─── Data ──────────────────────────────────────────────────────────────────
  final employeeScore = Rxn<EmployeeScoreModel>();
  final rankings = <RankingModel>[].obs;
  final reviews = <ReviewModel>[].obs;
  final myReviews = <ReviewModel>[].obs;

  // ✅ Roles
  final rolesList = <String>[].obs;

  // ─── Filter state ──────────────────────────────────────────────────────────
  final selectedMonth = DateTime.now().month.obs;
  final selectedYear = DateTime.now().year.obs;
  final selectedDept = ''.obs;

  // Date range for My Reviews
  final fromDate = Rx<DateTime>(
    DateTime(DateTime.now().year, DateTime.now().month, 1),
  );
  final toDate = Rx<DateTime>(
    DateTime(DateTime.now().year, DateTime.now().month + 1, 0),
  );

  // ─── Error ─────────────────────────────────────────────────────────────────
  final errorScore = ''.obs;
  final errorRanking = ''.obs;
  final errorReviews = ''.obs;
  final errorMyReviews = ''.obs;

  // ===========================================================================

  void setDateRange({required DateTime from, required DateTime to}) {
    fromDate.value = from;
    toDate.value = to;
  }

  Future<void> fetchMyReviews({
    required DateTime fromDate,
    required DateTime toDate,
  }) async {
    isLoadingMyReviews.value = true;
    errorMyReviews.value = '';
    myReviews.clear();

    try {
      final months = <({int month, int year})>[];
      var cursor = DateTime(fromDate.year, fromDate.month, 1);
      final end = DateTime(toDate.year, toDate.month, 1);

      while (!cursor.isAfter(end)) {
        months.add((month: cursor.month, year: cursor.year));
        cursor = DateTime(cursor.year, cursor.month + 1, 1);
      }

      final results = await Future.wait<List<ReviewModel>>(
        months.map(
          (m) => PerformanceApiService.getMyReviews(
            month: m.month,
            year: m.year,
          ),
        ),
      );

      final combined = results.expand<ReviewModel>((r) => r).toList()
        ..sort((a, b) {
          final cmpYear = b.year.compareTo(a.year);
          if (cmpYear != 0) return cmpYear;
          return b.month.compareTo(a.month);
        });

      myReviews.assignAll(combined);

      if (combined.isEmpty) {
        errorMyReviews.value = 'No reviews found for selected period.';
      }
    } catch (e) {
      errorMyReviews.value = 'Failed to load reviews: $e';
    } finally {
      isLoadingMyReviews.value = false;
    }
  }

  Future<void> fetchRoles() async {
    if (rolesList.isNotEmpty) return;
    isLoadingRoles.value = true;
    try {
      final result = await PerformanceApiService.getRoles();
      rolesList.value = result;
    } catch (_) {
      // silent
    } finally {
      isLoadingRoles.value = false;
    }
  }

  Future<void> fetchEmployeeScore({
    required int month,
    required int year,
    required int userId,
  }) async {
    isLoadingScore.value = true;
    errorScore.value = '';
    try {
      final result = await PerformanceApiService.getEmployeeScore(
        month: month,
        year: year,
        userId: userId,
      );
      employeeScore.value = result;
      if (result == null) errorScore.value = 'No score data found.';
    } catch (e) {
      errorScore.value = 'Failed to load score: $e';
    } finally {
      isLoadingScore.value = false;
    }
  }

  Future<void> fetchRanking({
    required int month,
    required int year,
    String? department,
  }) async {
    isLoadingRanking.value = true;
    errorRanking.value = '';
    try {
      final result = await PerformanceApiService.getRanking(
        month: month,
        year: year,
        department: department ?? selectedDept.value,
      );
      rankings.value = result;
      if (result.isEmpty) errorRanking.value = 'No ranking data found.';
    } catch (e) {
      errorRanking.value = 'Failed to load rankings: $e';
    } finally {
      isLoadingRanking.value = false;
    }
  }

  Future<void> fetchReviews({
    required int month,
    required int year,
  }) async {
    isLoadingReviews.value = true;
    errorReviews.value = '';
    try {
      final result = await PerformanceApiService.getReviews(
        month: month,
        year: year,
      );
      reviews.value = result;
    } catch (e) {
      errorReviews.value = 'Failed to load reviews: $e';
    } finally {
      isLoadingReviews.value = false;
    }
  }

  // =======================================================================
  // ✅ Submit Review (Admin)
  // - Uses API message (created/updated)
  // - Refreshes list after success
  // =======================================================================
  Future<bool> submitReview(ReviewRequestModel request) async {
    isSubmittingReview.value = true;
    try {
      final res = await PerformanceApiService.submitReview(request);

      if (res.success) {
        Get.snackbar(
          'Success',
          res.message.isNotEmpty ? res.message : 'Saved successfully',
          snackPosition: SnackPosition.TOP,
        );

        await fetchReviews(month: request.month, year: request.year);
        return true;
      } else {
        Get.snackbar(
          'Error',
          res.message.isNotEmpty ? res.message : 'Failed to submit review.',
          snackPosition: SnackPosition.TOP,
        );
        return false;
      }
    } catch (e) {
      Get.snackbar(
        'Error',
        e.toString(),
        snackPosition: SnackPosition.TOP,
      );
      return false;
    } finally {
      isSubmittingReview.value = false;
    }
  }

  // Helpers
  void setMonthYear(int month, int year) {
    selectedMonth.value = month;
    selectedYear.value = year;
  }

  void updateDepartment(String dept) {
    selectedDept.value = dept;
  }

  RankingModel? rankOf(int userId) =>
      rankings.firstWhereOrNull((r) => r.userId == userId);

  ReviewModel? reviewOf(int userId) =>
      reviews.firstWhereOrNull((r) => r.userId == userId);
}